exports.id = 527;
exports.ids = [527];
exports.modules = {

/***/ 4275:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/cancel.25908147.svg","height":512,"width":512});

/***/ }),

/***/ 4167:
/***/ (() => {

"use strict";
/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/cv.8d18d6ce.webp","height":570,"width":440,"blurDataURL":"data:image/webp;base64,UklGRjoAAABXRUJQVlA4IC4AAADwAQCdASoGAAgAAkA4JaQAAueG5J524AAA/uev/u31nxJH/WrQw1mCGuHVjZAA","blurWidth":6,"blurHeight":8});

/***/ }),

/***/ 6029:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/img-mobile.fb83fefe.jpg","height":300,"width":300,"blurDataURL":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAgACAMBIgACEQEDEQH/xAAnAAEBAAAAAAAAAAAAAAAAAAAABgEBAAAAAAAAAAAAAAAAAAAAAP/aAAwDAQACEAMQAAAArQf/xAAXEAEAAwAAAAAAAAAAAAAAAAARACNC/9oACAEBAAE/ALHJP//EABQRAQAAAAAAAAAAAAAAAAAAAAD/2gAIAQIBAT8Af//EABQRAQAAAAAAAAAAAAAAAAAAAAD/2gAIAQMBAT8Af//Z","blurWidth":8,"blurHeight":8});

/***/ }),

/***/ 6047:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _emailjs_browser__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7163);
/* harmony import */ var _emailjs_browser__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_emailjs_browser__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3590);
/* harmony import */ var react_toastify_dist_ReactToastify_css__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8819);
/* harmony import */ var react_toastify_dist_ReactToastify_css__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_toastify_dist_ReactToastify_css__WEBPACK_IMPORTED_MODULE_4__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_toastify__WEBPACK_IMPORTED_MODULE_3__]);
react_toastify__WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];





const Contact = ()=>{
    const form = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)();
    const sendEmail = (e)=>{
        e.preventDefault();
        _emailjs_browser__WEBPACK_IMPORTED_MODULE_2___default().sendForm("service_n4mkhz9", "template_ugoztxr", form.current, "user_vYmDSd9PwIuRXUQEDjYwN").then((result)=>{
            console.log(result);
            react_toastify__WEBPACK_IMPORTED_MODULE_3__.toast.success("Message Sent Successfully!", {
                position: "top-right",
                autoClose: 2000,
                hideProgressBar: false,
                closeOnClick: true,
                pauseOnHover: true,
                draggable: true,
                progress: undefined
            });
            document.getElementById("myForm").reset();
        }, (error)=>{
            react_toastify__WEBPACK_IMPORTED_MODULE_3__.toast.error("Ops Message Not Sent!", {
                position: "top-right",
                autoClose: 2000,
                hideProgressBar: false,
                closeOnClick: true,
                pauseOnHover: true,
                draggable: true,
                progress: undefined
            });
        });
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("form", {
            id: "myForm",
            className: "contactform",
            ref: form,
            onSubmit: sendEmail,
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "row",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "col-12 col-md-6",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "form-group",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                type: "text",
                                name: "name",
                                placeholder: "YOUR NAME",
                                required: true
                            })
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "col-12 col-md-6",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "form-group",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                type: "email",
                                name: "user_email",
                                placeholder: "YOUR EMAIL",
                                required: true
                            })
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "col-12 col-md-12",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "form-group",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                type: "text",
                                name: "subject",
                                placeholder: "YOUR SUBJECT",
                                required: true
                            })
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "col-12",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "form-group",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("textarea", {
                                name: "message",
                                placeholder: "YOUR MESSAGE",
                                required: true
                            })
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "col-12",
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("button", {
                            type: "submit",
                            className: "button",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    className: "button-text",
                                    children: "Send Message"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    className: "button-icon fa fa-send"
                                })
                            ]
                        })
                    })
                ]
            })
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Contact);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 9830:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);


const SocialShare = [
    {
        iconName: "fa fa-facebook",
        link: "https://www.facebook.com/"
    },
    {
        iconName: "fa fa-twitter",
        link: "https://twitter.com/"
    },
    {
        iconName: "fa fa-youtube",
        link: "https://www.youtube.com/"
    },
    {
        iconName: "fa fa-dribbble",
        link: "https://facebook.com/"
    }
];
const Social = ()=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
        className: "social list-unstyled pt-1 mb-5",
        children: SocialShare.map((val, i)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                    href: val.link,
                    target: "_blank",
                    rel: "noreferrer",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                        className: val.iconName
                    })
                })
            }, i))
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Social);


/***/ }),

/***/ 4318:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ blog_Blog)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: external "react-modal"
var external_react_modal_ = __webpack_require__(9931);
var external_react_modal_default = /*#__PURE__*/__webpack_require__.n(external_react_modal_);
// EXTERNAL MODULE: ./public/assets/img/cancel.svg
var cancel = __webpack_require__(4275);
;// CONCATENATED MODULE: ./public/assets/img/blog/quote.svg
/* harmony default export */ const quote = ({"src":"/_next/static/media/quote.11d91ddf.svg","height":349,"width":349});
// EXTERNAL MODULE: ./src/Context/ContextProvider.js + 7 modules
var ContextProvider = __webpack_require__(8443);
;// CONCATENATED MODULE: ./src/Hooks/UseData.js


const UseData = ()=>{
    return (0,external_react_.useContext)(ContextProvider/* MyContext */.I);
};
/* harmony default export */ const Hooks_UseData = (UseData);

// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
;// CONCATENATED MODULE: ./src/components/blog/Blog.jsx







const Blog = ()=>{
    const { singleData , isOpen , setIsOpen , blogsData , handleBlogsData  } = Hooks_UseData();
    const handleModle = (id)=>{
        handleBlogsData(id);
    };
    (0,external_react_.useEffect)(()=>{
        external_react_modal_default().setAppElement("#modal");
    }, []);
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: "row",
            id: "modal",
            children: blogsData.map((item)=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "col-12 col-md-6 col-lg-6 col-xl-4 mb-30",
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("article", {
                            className: "post-container",
                            onClick: ()=>handleModle(item?.id),
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "post-thumb",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "d-block position-relative overflow-hidden",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                            src: item?.img,
                                            className: "img-fluid",
                                            alt: "item.title"
                                        })
                                    })
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "post-content",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "entry-header",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                                children: item?.title
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "entry-content open-sans-font",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                children: item?.description1.slice(0, 100)
                                            })
                                        })
                                    ]
                                })
                            ]
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx((external_react_modal_default()), {
                            isOpen: isOpen,
                            onRequestClose: ()=>setIsOpen(false),
                            contentLabel: "My dialog",
                            className: "custom-modal dark",
                            overlayClassName: "custom-overlay dark",
                            closeTimeoutMS: 500,
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                        className: "close-modal",
                                        onClick: ()=>setIsOpen(false),
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                            src: cancel/* default */.Z,
                                            alt: "close icon"
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "box_inner blog-post",
                                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("article", {
                                            children: [
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                    className: "title-section text-start text-sm-center",
                                                    children: [
                                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h1", {
                                                            children: [
                                                                "Post ",
                                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                    children: "Details"
                                                                })
                                                            ]
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                            className: "title-bg",
                                                            children: "posts"
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                    className: "meta open-sans-font",
                                                    children: [
                                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                                            children: [
                                                                /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                                    className: "fa fa-user"
                                                                }),
                                                                " ",
                                                                singleData.commentor
                                                            ]
                                                        }),
                                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                                            className: "date",
                                                            children: [
                                                                /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                                    className: "fa fa-calendar"
                                                                }),
                                                                " ",
                                                                singleData.date
                                                            ]
                                                        }),
                                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                                            children: [
                                                                /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                                    className: "fa fa-tags"
                                                                }),
                                                                " ",
                                                                singleData.tag
                                                            ]
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                                                    children: singleData?.title
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                    src: singleData?.img,
                                                    className: "img-fluid",
                                                    alt: "Blog"
                                                }),
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                    className: "blog-excerpt open-sans-font pb-5",
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                            children: singleData?.description1
                                                        }),
                                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                            className: "quotebox",
                                                            children: [
                                                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                                    className: "icon",
                                                                    children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                                        src: quote,
                                                                        alt: "blog quote"
                                                                    })
                                                                }),
                                                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                                    children: singleData?.description2
                                                                })
                                                            ]
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                            children: singleData?.description3
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                            children: singleData?.description4
                                                        })
                                                    ]
                                                })
                                            ]
                                        })
                                    })
                                ]
                            })
                        })
                    ]
                }, item.id))
        })
    });
};
/* harmony default export */ const blog_Blog = (Blog);


/***/ }),

/***/ 1349:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ portfolio_Portfolio)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: external "react-tabs"
var external_react_tabs_ = __webpack_require__(5973);
;// CONCATENATED MODULE: ./public/assets/img/portfolio/project-1.jpg
/* harmony default export */ const project_1 = ({"src":"/_next/static/media/project-1.1bf819ab.jpg","height":552,"width":895,"blurDataURL":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAUACAMBIgACEQEDEQH/xAAnAAEBAAAAAAAAAAAAAAAAAAAABgEBAAAAAAAAAAAAAAAAAAAAAP/aAAwDAQACEAMQAAAArQf/xAAXEAADAQAAAAAAAAAAAAAAAAACERIA/9oACAEBAAE/AJJuy3//xAAUEQEAAAAAAAAAAAAAAAAAAAAA/9oACAECAQE/AH//xAAUEQEAAAAAAAAAAAAAAAAAAAAA/9oACAEDAQE/AH//2Q==","blurWidth":8,"blurHeight":5});
;// CONCATENATED MODULE: ./public/assets/img/portfolio/project-2.jpg
/* harmony default export */ const project_2 = ({"src":"/_next/static/media/project-2.1bf819ab.jpg","height":552,"width":895,"blurDataURL":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAUACAMBIgACEQEDEQH/xAAnAAEBAAAAAAAAAAAAAAAAAAAABgEBAAAAAAAAAAAAAAAAAAAAAP/aAAwDAQACEAMQAAAArQf/xAAXEAADAQAAAAAAAAAAAAAAAAACERIA/9oACAEBAAE/AJJuy3//xAAUEQEAAAAAAAAAAAAAAAAAAAAA/9oACAECAQE/AH//xAAUEQEAAAAAAAAAAAAAAAAAAAAA/9oACAEDAQE/AH//2Q==","blurWidth":8,"blurHeight":5});
;// CONCATENATED MODULE: ./public/assets/img/portfolio/project-3.jpg
/* harmony default export */ const project_3 = ({"src":"/_next/static/media/project-3.1bf819ab.jpg","height":552,"width":895,"blurDataURL":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAUACAMBIgACEQEDEQH/xAAnAAEBAAAAAAAAAAAAAAAAAAAABgEBAAAAAAAAAAAAAAAAAAAAAP/aAAwDAQACEAMQAAAArQf/xAAXEAADAQAAAAAAAAAAAAAAAAACERIA/9oACAEBAAE/AJJuy3//xAAUEQEAAAAAAAAAAAAAAAAAAAAA/9oACAECAQE/AH//xAAUEQEAAAAAAAAAAAAAAAAAAAAA/9oACAEDAQE/AH//2Q==","blurWidth":8,"blurHeight":5});
;// CONCATENATED MODULE: ./public/assets/img/portfolio/project-4.jpg
/* harmony default export */ const project_4 = ({"src":"/_next/static/media/project-4.1bf819ab.jpg","height":552,"width":895,"blurDataURL":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAUACAMBIgACEQEDEQH/xAAnAAEBAAAAAAAAAAAAAAAAAAAABgEBAAAAAAAAAAAAAAAAAAAAAP/aAAwDAQACEAMQAAAArQf/xAAXEAADAQAAAAAAAAAAAAAAAAACERIA/9oACAEBAAE/AJJuy3//xAAUEQEAAAAAAAAAAAAAAAAAAAAA/9oACAECAQE/AH//xAAUEQEAAAAAAAAAAAAAAAAAAAAA/9oACAEDAQE/AH//2Q==","blurWidth":8,"blurHeight":5});
;// CONCATENATED MODULE: ./public/assets/img/portfolio/project-5.jpg
/* harmony default export */ const project_5 = ({"src":"/_next/static/media/project-5.1bf819ab.jpg","height":552,"width":895,"blurDataURL":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAUACAMBIgACEQEDEQH/xAAnAAEBAAAAAAAAAAAAAAAAAAAABgEBAAAAAAAAAAAAAAAAAAAAAP/aAAwDAQACEAMQAAAArQf/xAAXEAADAQAAAAAAAAAAAAAAAAACERIA/9oACAEBAAE/AJJuy3//xAAUEQEAAAAAAAAAAAAAAAAAAAAA/9oACAECAQE/AH//xAAUEQEAAAAAAAAAAAAAAAAAAAAA/9oACAEDAQE/AH//2Q==","blurWidth":8,"blurHeight":5});
;// CONCATENATED MODULE: ./public/assets/img/portfolio/project-6.jpg
/* harmony default export */ const project_6 = ({"src":"/_next/static/media/project-6.1bf819ab.jpg","height":552,"width":895,"blurDataURL":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAUACAMBIgACEQEDEQH/xAAnAAEBAAAAAAAAAAAAAAAAAAAABgEBAAAAAAAAAAAAAAAAAAAAAP/aAAwDAQACEAMQAAAArQf/xAAXEAADAQAAAAAAAAAAAAAAAAACERIA/9oACAEBAAE/AJJuy3//xAAUEQEAAAAAAAAAAAAAAAAAAAAA/9oACAECAQE/AH//xAAUEQEAAAAAAAAAAAAAAAAAAAAA/9oACAEDAQE/AH//2Q==","blurWidth":8,"blurHeight":5});
;// CONCATENATED MODULE: ./public/assets/img/portfolio/project-7.jpg
/* harmony default export */ const project_7 = ({"src":"/_next/static/media/project-7.1bf819ab.jpg","height":552,"width":895,"blurDataURL":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAUACAMBIgACEQEDEQH/xAAnAAEBAAAAAAAAAAAAAAAAAAAABgEBAAAAAAAAAAAAAAAAAAAAAP/aAAwDAQACEAMQAAAArQf/xAAXEAADAQAAAAAAAAAAAAAAAAACERIA/9oACAEBAAE/AJJuy3//xAAUEQEAAAAAAAAAAAAAAAAAAAAA/9oACAECAQE/AH//xAAUEQEAAAAAAAAAAAAAAAAAAAAA/9oACAEDAQE/AH//2Q==","blurWidth":8,"blurHeight":5});
;// CONCATENATED MODULE: ./public/assets/img/portfolio/project-8.jpg
/* harmony default export */ const project_8 = ({"src":"/_next/static/media/project-8.1bf819ab.jpg","height":552,"width":895,"blurDataURL":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAUACAMBIgACEQEDEQH/xAAnAAEBAAAAAAAAAAAAAAAAAAAABgEBAAAAAAAAAAAAAAAAAAAAAP/aAAwDAQACEAMQAAAArQf/xAAXEAADAQAAAAAAAAAAAAAAAAACERIA/9oACAEBAAE/AJJuy3//xAAUEQEAAAAAAAAAAAAAAAAAAAAA/9oACAECAQE/AH//xAAUEQEAAAAAAAAAAAAAAAAAAAAA/9oACAEDAQE/AH//2Q==","blurWidth":8,"blurHeight":5});
;// CONCATENATED MODULE: ./public/assets/img/portfolio/project-9.jpg
/* harmony default export */ const project_9 = ({"src":"/_next/static/media/project-9.1bf819ab.jpg","height":552,"width":895,"blurDataURL":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAUACAMBIgACEQEDEQH/xAAnAAEBAAAAAAAAAAAAAAAAAAAABgEBAAAAAAAAAAAAAAAAAAAAAP/aAAwDAQACEAMQAAAArQf/xAAXEAADAQAAAAAAAAAAAAAAAAACERIA/9oACAEBAAE/AJJuy3//xAAUEQEAAAAAAAAAAAAAAAAAAAAA/9oACAECAQE/AH//xAAUEQEAAAAAAAAAAAAAAAAAAAAA/9oACAEDAQE/AH//2Q==","blurWidth":8,"blurHeight":5});
;// CONCATENATED MODULE: ./src/components/portfolio/portfolioData.js









const PortfolioData = [
    {
        id: 1,
        type: "mockup project",
        image: project_1,
        tag: [
            "mockup"
        ],
        delayAnimation: "0",
        modalDetails: [
            {
                project: "Website",
                client: "Envato",
                language: "HTML, CSS, Javascript",
                preview: "www.envato.com",
                link: "https://www.envato.com/"
            }
        ]
    },
    {
        id: 2,
        type: "youtube project",
        image: project_2,
        tag: [
            "video"
        ],
        delayAnimation: "100",
        modalDetails: [
            {
                project: "video",
                client: "Videohive",
                language: " Adobe After Effects",
                preview: "www.videohive.net",
                link: "https://www.videohive.net"
            }
        ]
    },
    {
        id: 3,
        type: "slider project",
        image: project_3,
        tag: [],
        delayAnimation: "200",
        modalDetails: [
            {
                project: "Website",
                client: "Themeforest",
                language: " HTML, CSS, Javascript",
                preview: "www.envato.com",
                link: "https://www.envato.com"
            }
        ]
    },
    {
        id: 4,
        type: "local project",
        image: project_4,
        tag: [
            "logo",
            "video"
        ],
        delayAnimation: "0",
        modalDetails: [
            {
                project: "video",
                client: "Videohive",
                language: " Adobe After Effects",
                preview: "www.videohive.net",
                link: "https://www.videohive.net"
            }
        ]
    },
    {
        id: 5,
        type: "saas project",
        image: project_5,
        tag: [
            "logo"
        ],
        delayAnimation: "100",
        modalDetails: [
            {
                project: "Web Application",
                client: "Themeforest",
                language: "HTML, CSS, ReactJS",
                preview: "www.envato.com",
                link: "https://themeforest.net/item/deski-saas-software-react-template/33799794"
            }
        ]
    },
    {
        id: 6,
        type: "mockup project",
        image: project_6,
        tag: [
            "logo",
            "mockup"
        ],
        delayAnimation: "200",
        modalDetails: [
            {
                project: "Website",
                client: "Themeforest",
                language: "HTML, CSS, Javascript",
                preview: "www.pexels.com",
                link: "https://www.pexels.com"
            }
        ]
    },
    {
        id: 7,
        type: "facebook project",
        image: project_7,
        tag: [
            "logo"
        ],
        delayAnimation: "0",
        modalDetails: [
            {
                project: "Website",
                client: "Facebook",
                language: "HTML, CSS, Javascript",
                preview: "www.facebook.com",
                link: "https://www.facebook.com/ibthemes"
            }
        ]
    },
    {
        id: 8,
        type: "dribble project",
        image: project_8,
        tag: [
            "graphic design"
        ],
        delayAnimation: "100",
        modalDetails: [
            {
                project: "Website",
                client: "Dribbble",
                language: "HTML, CSS, Javascript",
                preview: "www.dribbble.com",
                link: "https://dribbble.com/ib-themes"
            }
        ]
    },
    {
        id: 9,
        type: "behence project",
        image: project_9,
        tag: [
            "graphic design",
            "mockup"
        ],
        delayAnimation: "200",
        modalDetails: [
            {
                project: "Website",
                client: "Behance",
                language: "HTML, CSS, Javascript",
                preview: "www.behance.com",
                link: "https://www.behance.net/ib-themes"
            }
        ]
    }
];
/* harmony default export */ const portfolioData = (PortfolioData);

// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: ./public/assets/img/cancel.svg
var cancel = __webpack_require__(4275);
;// CONCATENATED MODULE: ./src/components/portfolio/modal/modal-by-id/ModalOne.jsx





const ModalOne = ({ modalId , setGetModal  })=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "modal_portfolio ",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "modal__outside",
                onClick: ()=>setGetModal(false)
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {}),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "modal__content",
                children: portfolioData.filter((item)=>item.id === modalId).map((item)=>{
                    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        "data-aos": "fade",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                className: "heading mb-2",
                                children: item.type
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "modal__details",
                                children: item.modalDetails.map((details, i)=>{
                                    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "row open-sans-font",
                                        children: [
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: "col-12 col-sm-6 mb-2",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                        className: "fa fa-file-text-o pr-2"
                                                    }),
                                                    "Project:",
                                                    " ",
                                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                        className: "ft-wt-600 uppercase",
                                                        children: details.project
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: "col-12 col-sm-6 mb-2",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                        className: "fa fa-user-o pr-2"
                                                    }),
                                                    "Client :",
                                                    " ",
                                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                        className: "ft-wt-600 uppercase",
                                                        children: details.client
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: "col-12 col-sm-6 mb-2",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                        className: "fa fa-code pr-2"
                                                    }),
                                                    "Language :",
                                                    " ",
                                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                        className: "ft-wt-600 uppercase",
                                                        children: details.language
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: "col-12 col-sm-6 mb-2",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                        className: "fa fa-external-link pr-2"
                                                    }),
                                                    "Preview :",
                                                    " ",
                                                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                        className: "preview-link",
                                                        target: "_blank",
                                                        rel: "noopener noreferrer nofollow",
                                                        href: details.link,
                                                        children: details.preview
                                                    })
                                                ]
                                            })
                                        ]
                                    }, i);
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("figure", {
                                className: "modal__img",
                                children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                    src: item.image,
                                    alt: "portfolio project demo"
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                className: "close-modal",
                                onClick: ()=>setGetModal(false),
                                children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                    src: cancel/* default */.Z,
                                    alt: "portfolio project demo"
                                })
                            })
                        ]
                    }, item.id);
                })
            })
        ]
    });
};
/* harmony default export */ const modal_by_id_ModalOne = (ModalOne);

;// CONCATENATED MODULE: ./src/components/portfolio/modal/modal-by-id/ModalTwo.jsx





const ModalTwo = ({ modalId , setGetModal  })=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "modal_portfolio",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "modal__outside",
                onClick: ()=>setGetModal(false)
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "modal__content",
                children: portfolioData.filter((item)=>item.id === modalId).map((item)=>{
                    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        "data-aos": "fade",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                className: "heading mb-2",
                                children: item.type
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "modal__details",
                                children: item.modalDetails.map((details, i)=>{
                                    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "row open-sans-font",
                                        children: [
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: "col-12 col-sm-6 mb-2",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                        className: "fa fa-file-text-o pr-2"
                                                    }),
                                                    "Project:",
                                                    " ",
                                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                        className: "ft-wt-600 uppercase",
                                                        children: details.project
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: "col-12 col-sm-6 mb-2",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                        className: "fa fa-user-o pr-2"
                                                    }),
                                                    "Client :",
                                                    " ",
                                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                        className: "ft-wt-600 uppercase",
                                                        children: details.client
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: "col-12 col-sm-6 mb-2",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                        className: "fa fa-code pr-2"
                                                    }),
                                                    "Language :",
                                                    " ",
                                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                        className: "ft-wt-600 uppercase",
                                                        children: details.language
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: "col-12 col-sm-6 mb-2",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                        className: "fa fa-external-link pr-2"
                                                    }),
                                                    "Preview :",
                                                    " ",
                                                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                        className: "preview-link",
                                                        target: "_blank",
                                                        rel: "noopener noreferrer nofollow",
                                                        href: details.link,
                                                        children: details.preview
                                                    })
                                                ]
                                            })
                                        ]
                                    }, i);
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("figure", {
                                className: "modal__img videocontainer",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("iframe", {
                                    src: "https://www.youtube.com/embed/7e90gBu4pas",
                                    title: "YouTube video player",
                                    className: "youtube-video",
                                    allowFullScreen: true
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                className: "close-modal",
                                onClick: ()=>setGetModal(false),
                                children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                    src: cancel/* default */.Z,
                                    alt: "portfolio project demo"
                                })
                            })
                        ]
                    }, item.id);
                })
            })
        ]
    });
};
/* harmony default export */ const modal_by_id_ModalTwo = (ModalTwo);

// EXTERNAL MODULE: external "react-slick"
var external_react_slick_ = __webpack_require__(8096);
var external_react_slick_default = /*#__PURE__*/__webpack_require__.n(external_react_slick_);
// EXTERNAL MODULE: ./node_modules/slick-carousel/slick/slick.css
var slick = __webpack_require__(8278);
// EXTERNAL MODULE: ./node_modules/slick-carousel/slick/slick-theme.css
var slick_theme = __webpack_require__(782);
;// CONCATENATED MODULE: ./src/components/portfolio/modal/modal-by-id/ModalThree.jsx
// external






// internal




const ModalThree = ({ modalId , setGetModal  })=>{
    let settings = {
        dots: true,
        infinite: true,
        speed: 500,
        slidesToShow: 1,
        slidesToScroll: 1,
        draggable: true
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "modal_portfolio",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "modal__outside",
                onClick: ()=>setGetModal(false)
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "modal__content",
                children: portfolioData.filter((item)=>item.id === modalId).map((item)=>{
                    //
                    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        "data-aos": "fade",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                className: "heading mb-2",
                                children: item.type
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "modal__details",
                                children: item.modalDetails.map((details, i)=>{
                                    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "row open-sans-font",
                                        children: [
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: "col-12 col-sm-6 mb-2",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                        className: "fa fa-file-text-o pr-2"
                                                    }),
                                                    "Project:",
                                                    " ",
                                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                        className: "ft-wt-600 uppercase",
                                                        children: details.project
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: "col-12 col-sm-6 mb-2",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                        className: "fa fa-user-o pr-2"
                                                    }),
                                                    "Client :",
                                                    " ",
                                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                        className: "ft-wt-600 uppercase",
                                                        children: details.client
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: "col-12 col-sm-6 mb-2",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                        className: "fa fa-code pr-2"
                                                    }),
                                                    "Language :",
                                                    " ",
                                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                        className: "ft-wt-600 uppercase",
                                                        children: details.language
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: "col-12 col-sm-6 mb-2",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                        className: "fa fa-external-link pr-2"
                                                    }),
                                                    "Preview :",
                                                    " ",
                                                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                        className: "preview-link",
                                                        target: "_blank",
                                                        rel: "noopener noreferrer nofollow",
                                                        href: details.link,
                                                        children: details.preview
                                                    })
                                                ]
                                            })
                                        ]
                                    }, i);
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("figure", {
                                className: "modal__img",
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((external_react_slick_default()), {
                                    ...settings,
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                src: item.image,
                                                alt: "portfolio project demo"
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                src: project_1,
                                                alt: "portfolio project demo"
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                src: project_2,
                                                alt: "portfolio project demo"
                                            })
                                        })
                                    ]
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                className: "close-modal",
                                onClick: ()=>setGetModal(false),
                                children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                    src: cancel/* default */.Z,
                                    alt: "portfolio project demo"
                                })
                            })
                        ]
                    }, item.id);
                })
            })
        ]
    });
};
/* harmony default export */ const modal_by_id_ModalThree = (ModalThree);

;// CONCATENATED MODULE: ./src/components/portfolio/modal/modal-by-id/ModalFour.jsx





const ModalFour = ({ modalId , setGetModal  })=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "modal_portfolio",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "modal__outside",
                onClick: ()=>setGetModal(false)
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "modal__content",
                children: portfolioData.filter((item)=>item.id === modalId).map((item)=>{
                    //
                    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        "data-aos": "fade",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                className: "heading mb-2",
                                children: item.type
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "modal__details",
                                children: item.modalDetails.map((details, i)=>{
                                    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "row open-sans-font",
                                        children: [
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: "col-12 col-sm-6 mb-2",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                        className: "fa fa-file-text-o pr-2"
                                                    }),
                                                    "Project:",
                                                    " ",
                                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                        className: "ft-wt-600 uppercase",
                                                        children: details.project
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: "col-12 col-sm-6 mb-2",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                        className: "fa fa-user-o pr-2"
                                                    }),
                                                    "Client :",
                                                    " ",
                                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                        className: "ft-wt-600 uppercase",
                                                        children: details.client
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: "col-12 col-sm-6 mb-2",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                        className: "fa fa-code pr-2"
                                                    }),
                                                    "Language :",
                                                    " ",
                                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                        className: "ft-wt-600 uppercase",
                                                        children: details.language
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: "col-12 col-sm-6 mb-2",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                        className: "fa fa-external-link pr-2"
                                                    }),
                                                    "Preview :",
                                                    " ",
                                                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                        className: "preview-link",
                                                        target: "_blank",
                                                        rel: "noopener noreferrer nofollow",
                                                        href: details.link,
                                                        children: details.preview
                                                    })
                                                ]
                                            })
                                        ]
                                    }, i);
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("figure", {
                                className: "modal__img",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("video", {
                                    id: "video",
                                    className: "responsive-video",
                                    controls: true,
                                    poster: item.image,
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("source", {
                                        src: "/assets/img/portfolio/video.mp4",
                                        type: "video/mp4"
                                    })
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                className: "close-modal",
                                onClick: ()=>setGetModal(false),
                                children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                    src: cancel/* default */.Z,
                                    alt: "portfolio project demo"
                                })
                            })
                        ]
                    }, item.id);
                })
            })
        ]
    });
};
/* harmony default export */ const modal_by_id_ModalFour = (ModalFour);

;// CONCATENATED MODULE: ./src/components/portfolio/modal/modal-by-id/ModalFive.jsx





const ModalFive = ({ modalId , setGetModal  })=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "modal_portfolio",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "modal__outside",
                onClick: ()=>setGetModal(false)
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "modal__content",
                children: portfolioData.filter((item)=>item.id === modalId).map((item)=>{
                    //
                    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        "data-aos": "fade",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                className: "heading mb-2",
                                children: item.type
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "modal__details",
                                children: item.modalDetails.map((details, i)=>{
                                    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "row open-sans-font",
                                        children: [
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: "col-12 col-sm-6 mb-2",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                        className: "fa fa-file-text-o pr-2"
                                                    }),
                                                    "Project:",
                                                    " ",
                                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                        className: "ft-wt-600 uppercase",
                                                        children: details.project
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: "col-12 col-sm-6 mb-2",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                        className: "fa fa-user-o pr-2"
                                                    }),
                                                    "Client :",
                                                    " ",
                                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                        className: "ft-wt-600 uppercase",
                                                        children: details.client
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: "col-12 col-sm-6 mb-2",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                        className: "fa fa-code pr-2"
                                                    }),
                                                    "Language :",
                                                    " ",
                                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                        className: "ft-wt-600 uppercase",
                                                        children: details.language
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: "col-12 col-sm-6 mb-2",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                        className: "fa fa-external-link pr-2"
                                                    }),
                                                    "Preview :",
                                                    " ",
                                                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                        className: "preview-link",
                                                        target: "_blank",
                                                        rel: "noopener noreferrer nofollow",
                                                        href: details.link,
                                                        children: details.preview
                                                    })
                                                ]
                                            })
                                        ]
                                    }, i);
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("figure", {
                                className: "modal__img",
                                children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                    src: item.image,
                                    alt: "portfolio project demo"
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                className: "close-modal",
                                onClick: ()=>setGetModal(false),
                                children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                    src: cancel/* default */.Z,
                                    alt: "portfolio project demo"
                                })
                            })
                        ]
                    }, item.id);
                })
            })
        ]
    });
};
/* harmony default export */ const modal_by_id_ModalFive = (ModalFive);

;// CONCATENATED MODULE: ./src/components/portfolio/modal/modal-by-id/ModalSix.jsx





const ModalSix = ({ modalId , setGetModal  })=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "modal_portfolio",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "modal__outside",
                onClick: ()=>setGetModal(false)
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "modal__content",
                children: portfolioData.filter((item)=>item.id === modalId).map((item)=>{
                    //
                    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        "data-aos": "fade",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                className: "heading mb-2",
                                children: item.type
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "modal__details",
                                children: item.modalDetails.map((details, i)=>{
                                    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "row open-sans-font",
                                        children: [
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: "col-12 col-sm-6 mb-2",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                        className: "fa fa-file-text-o pr-2"
                                                    }),
                                                    "Project:",
                                                    " ",
                                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                        className: "ft-wt-600 uppercase",
                                                        children: details.project
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: "col-12 col-sm-6 mb-2",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                        className: "fa fa-user-o pr-2"
                                                    }),
                                                    "Client :",
                                                    " ",
                                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                        className: "ft-wt-600 uppercase",
                                                        children: details.client
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: "col-12 col-sm-6 mb-2",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                        className: "fa fa-code pr-2"
                                                    }),
                                                    "Language :",
                                                    " ",
                                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                        className: "ft-wt-600 uppercase",
                                                        children: details.language
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: "col-12 col-sm-6 mb-2",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                        className: "fa fa-external-link pr-2"
                                                    }),
                                                    "Preview :",
                                                    " ",
                                                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                        className: "preview-link",
                                                        target: "_blank",
                                                        rel: "noopener noreferrer nofollow",
                                                        href: details.link,
                                                        children: details.preview
                                                    })
                                                ]
                                            })
                                        ]
                                    }, i);
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("figure", {
                                className: "modal__img",
                                children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                    src: item.image,
                                    alt: "portfolio project demo"
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                className: "close-modal",
                                onClick: ()=>setGetModal(false),
                                children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                    src: cancel/* default */.Z,
                                    alt: "portfolio project demo"
                                })
                            })
                        ]
                    }, item.id);
                })
            })
        ]
    });
};
/* harmony default export */ const modal_by_id_ModalSix = (ModalSix);

;// CONCATENATED MODULE: ./src/components/portfolio/modal/modal-by-id/ModalSeven.jsx





const ModalSeven = ({ modalId , setGetModal  })=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "modal_portfolio",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "modal__outside",
                onClick: ()=>setGetModal(false)
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "modal__content",
                children: portfolioData.filter((item)=>item.id === modalId).map((item)=>{
                    //
                    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        "data-aos": "fade",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                className: "heading mb-2",
                                children: item.type
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "modal__details",
                                children: item.modalDetails.map((details, i)=>{
                                    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "row open-sans-font",
                                        children: [
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: "col-12 col-sm-6 mb-2",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                        className: "fa fa-file-text-o pr-2"
                                                    }),
                                                    "Project:",
                                                    " ",
                                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                        className: "ft-wt-600 uppercase",
                                                        children: details.project
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: "col-12 col-sm-6 mb-2",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                        className: "fa fa-user-o pr-2"
                                                    }),
                                                    "Client :",
                                                    " ",
                                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                        className: "ft-wt-600 uppercase",
                                                        children: details.client
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: "col-12 col-sm-6 mb-2",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                        className: "fa fa-code pr-2"
                                                    }),
                                                    "Language :",
                                                    " ",
                                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                        className: "ft-wt-600 uppercase",
                                                        children: details.language
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: "col-12 col-sm-6 mb-2",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                        className: "fa fa-external-link pr-2"
                                                    }),
                                                    "Preview :",
                                                    " ",
                                                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                        className: "preview-link",
                                                        target: "_blank",
                                                        rel: "noopener noreferrer nofollow",
                                                        href: details.link,
                                                        children: details.preview
                                                    })
                                                ]
                                            })
                                        ]
                                    }, i);
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("figure", {
                                className: "modal__img",
                                children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                    src: item.image,
                                    alt: "portfolio project demo"
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                className: "close-modal",
                                onClick: ()=>setGetModal(false),
                                children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                    src: cancel/* default */.Z,
                                    alt: "portfolio project demo"
                                })
                            })
                        ]
                    }, item.id);
                })
            })
        ]
    });
};
/* harmony default export */ const modal_by_id_ModalSeven = (ModalSeven);

;// CONCATENATED MODULE: ./src/components/portfolio/modal/modal-by-id/ModalEight.jsx





const ModalEight = ({ modalId , setGetModal  })=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "modal_portfolio",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "modal__outside",
                onClick: ()=>setGetModal(false)
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "modal__content",
                children: portfolioData.filter((item)=>item.id === modalId).map((item)=>{
                    //
                    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        "data-aos": "fade",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                className: "heading mb-2",
                                children: item.type
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "modal__details",
                                children: item.modalDetails.map((details, i)=>{
                                    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "row open-sans-font",
                                        children: [
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: "col-12 col-sm-6 mb-2",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                        className: "fa fa-file-text-o pr-2"
                                                    }),
                                                    "Project:",
                                                    " ",
                                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                        className: "ft-wt-600 uppercase",
                                                        children: details.project
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: "col-12 col-sm-6 mb-2",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                        className: "fa fa-user-o pr-2"
                                                    }),
                                                    "Client :",
                                                    " ",
                                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                        className: "ft-wt-600 uppercase",
                                                        children: details.client
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: "col-12 col-sm-6 mb-2",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                        className: "fa fa-code pr-2"
                                                    }),
                                                    "Language :",
                                                    " ",
                                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                        className: "ft-wt-600 uppercase",
                                                        children: details.language
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: "col-12 col-sm-6 mb-2",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                        className: "fa fa-external-link pr-2"
                                                    }),
                                                    "Preview :",
                                                    " ",
                                                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                        className: "preview-link",
                                                        target: "_blank",
                                                        rel: "noopener noreferrer nofollow",
                                                        href: details.link,
                                                        children: details.preview
                                                    })
                                                ]
                                            })
                                        ]
                                    }, i);
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("figure", {
                                className: "modal__img",
                                children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                    src: item.image,
                                    alt: "portfolio project demo"
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                className: "close-modal",
                                onClick: ()=>setGetModal(false),
                                children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                    src: cancel/* default */.Z,
                                    alt: "portfolio project demo"
                                })
                            })
                        ]
                    }, item.id);
                })
            })
        ]
    });
};
/* harmony default export */ const modal_by_id_ModalEight = (ModalEight);

;// CONCATENATED MODULE: ./src/components/portfolio/modal/modal-by-id/ModalNine.jsx





const ModalNine = ({ modalId , setGetModal  })=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "modal_portfolio",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "modal__outside",
                onClick: ()=>setGetModal(false)
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "modal__content",
                children: portfolioData.filter((item)=>item.id === modalId).map((item)=>{
                    //
                    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        "data-aos": "fade",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                className: "heading mb-2",
                                children: item.type
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "modal__details",
                                children: item.modalDetails.map((details, i)=>{
                                    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "row open-sans-font",
                                        children: [
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: "col-12 col-sm-6 mb-2",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                        className: "fa fa-file-text-o pr-2"
                                                    }),
                                                    "Project:",
                                                    " ",
                                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                        className: "ft-wt-600 uppercase",
                                                        children: details.project
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: "col-12 col-sm-6 mb-2",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                        className: "fa fa-user-o pr-2"
                                                    }),
                                                    "Client :",
                                                    " ",
                                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                        className: "ft-wt-600 uppercase",
                                                        children: details.client
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: "col-12 col-sm-6 mb-2",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                        className: "fa fa-code pr-2"
                                                    }),
                                                    "Language :",
                                                    " ",
                                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                        className: "ft-wt-600 uppercase",
                                                        children: details.language
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: "col-12 col-sm-6 mb-2",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                        className: "fa fa-external-link pr-2"
                                                    }),
                                                    "Preview :",
                                                    " ",
                                                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                        className: "preview-link",
                                                        target: "_blank",
                                                        rel: "noopener noreferrer nofollow",
                                                        href: details.link,
                                                        children: details.preview
                                                    })
                                                ]
                                            })
                                        ]
                                    }, i);
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("figure", {
                                className: "modal__img",
                                children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                    src: item.image,
                                    alt: "portfolio project demo"
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                className: "close-modal",
                                onClick: ()=>setGetModal(false),
                                children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                    src: cancel/* default */.Z,
                                    alt: "portfolio project demo"
                                })
                            })
                        ]
                    }, item.id);
                })
            })
        ]
    });
};
/* harmony default export */ const modal_by_id_ModalNine = (ModalNine);

;// CONCATENATED MODULE: ./src/components/portfolio/modal/ModalMain.jsx











const ModalMain = ({ modalId , setGetModal  })=>{
    if (modalId === 1) {
        return /*#__PURE__*/ jsx_runtime_.jsx(modal_by_id_ModalOne, {
            modalId: modalId,
            setGetModal: setGetModal
        });
    } else if (modalId === 2) {
        return /*#__PURE__*/ jsx_runtime_.jsx(modal_by_id_ModalTwo, {
            modalId: modalId,
            setGetModal: setGetModal
        });
    } else if (modalId === 3) {
        return /*#__PURE__*/ jsx_runtime_.jsx(modal_by_id_ModalThree, {
            modalId: modalId,
            setGetModal: setGetModal
        });
    } else if (modalId === 4) {
        return /*#__PURE__*/ jsx_runtime_.jsx(modal_by_id_ModalFour, {
            modalId: modalId,
            setGetModal: setGetModal
        });
    } else if (modalId === 5) {
        return /*#__PURE__*/ jsx_runtime_.jsx(modal_by_id_ModalFive, {
            modalId: modalId,
            setGetModal: setGetModal
        });
    } else if (modalId === 6) {
        return /*#__PURE__*/ jsx_runtime_.jsx(modal_by_id_ModalSix, {
            modalId: modalId,
            setGetModal: setGetModal
        });
    } else if (modalId === 7) {
        return /*#__PURE__*/ jsx_runtime_.jsx(modal_by_id_ModalSeven, {
            modalId: modalId,
            setGetModal: setGetModal
        });
    } else if (modalId === 8) {
        return /*#__PURE__*/ jsx_runtime_.jsx(modal_by_id_ModalEight, {
            modalId: modalId,
            setGetModal: setGetModal
        });
    } else if (modalId === 9) {
        return /*#__PURE__*/ jsx_runtime_.jsx(modal_by_id_ModalNine, {
            modalId: modalId,
            setGetModal: setGetModal
        });
    }
};
/* harmony default export */ const modal_ModalMain = (ModalMain);

;// CONCATENATED MODULE: ./src/components/portfolio/Portfolio.jsx






const Portfolio = ()=>{
    const [getModal, setGetModal] = (0,external_react_.useState)(false);
    const [modalId, setModalId] = (0,external_react_.useState)(1);
    const handleModal = (id)=>{
        setGetModal(true);
        setModalId(id);
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "portfolio-main",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(external_react_tabs_.Tabs, {
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)(external_react_tabs_.TabList, {
                            className: "portfolio-tab-list",
                            "data-aos": "fade-up",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx(external_react_tabs_.Tab, {
                                    children: "ALL"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(external_react_tabs_.Tab, {
                                    children: "LOGO"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(external_react_tabs_.Tab, {
                                    children: "VIDEO"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(external_react_tabs_.Tab, {
                                    children: "GRAPHIC DESIGN"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(external_react_tabs_.Tab, {
                                    children: "MOCKUP"
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "container",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx(external_react_tabs_.TabPanel, {
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "tab-container",
                                        children: portfolioData.map((item)=>{
                                            const { id , type , image , delayAnimation  } = item;
                                            return /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                "data-aos": "fade-right",
                                                "data-aos-delay": delayAnimation,
                                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                    className: "tab-content",
                                                    onClick: ()=>handleModal(id),
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                            src: image,
                                                            alt: "portfolio project demo"
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                                            children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                className: "conent-title",
                                                                children: type
                                                            })
                                                        })
                                                    ]
                                                })
                                            }, id);
                                        })
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(external_react_tabs_.TabPanel, {
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "tab-container",
                                        children: portfolioData.filter((item)=>item.tag.includes("logo")).map((item)=>{
                                            const { id , type , image , delayAnimation  } = item;
                                            return /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                "data-aos": "fade-right",
                                                "data-aos-delay": delayAnimation,
                                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                    className: "tab-content",
                                                    onClick: ()=>handleModal(id),
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                            src: image,
                                                            alt: "portfolio project demo"
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                                            children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                className: "conent-title",
                                                                children: type
                                                            })
                                                        })
                                                    ]
                                                })
                                            }, id);
                                        })
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(external_react_tabs_.TabPanel, {
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "tab-container",
                                        children: portfolioData.filter((item)=>item.tag.includes("video")).map((item)=>{
                                            const { id , type , image , delayAnimation  } = item;
                                            return /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                "data-aos": "fade-right",
                                                "data-aos-delay": delayAnimation,
                                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                    className: "tab-content",
                                                    onClick: ()=>handleModal(id),
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                            src: image,
                                                            alt: "portfolio project demo"
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                                            children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                className: "conent-title",
                                                                children: type
                                                            })
                                                        })
                                                    ]
                                                })
                                            }, id);
                                        })
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(external_react_tabs_.TabPanel, {
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "tab-container",
                                        children: portfolioData.filter((item)=>item.tag.includes("graphic design")).map((item)=>{
                                            const { id , type , image , delayAnimation  } = item;
                                            return /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                "data-aos": "fade-right",
                                                "data-aos-delay": delayAnimation,
                                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                    className: "tab-content",
                                                    onClick: ()=>handleModal(id),
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                            src: image,
                                                            alt: "portfolio project demo"
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                                            children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                className: "conent-title",
                                                                children: type
                                                            })
                                                        })
                                                    ]
                                                })
                                            }, id);
                                        })
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(external_react_tabs_.TabPanel, {
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "tab-container",
                                        children: portfolioData.filter((item)=>item.tag.includes("mockup")).map((item)=>{
                                            const { id , type , image , delayAnimation  } = item;
                                            return /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                "data-aos": "fade-right",
                                                "data-aos-delay": delayAnimation,
                                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                    className: "tab-content",
                                                    onClick: ()=>handleModal(id),
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                            src: image,
                                                            alt: "portfolio project demo"
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                                            children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                className: "conent-title",
                                                                children: type
                                                            })
                                                        })
                                                    ]
                                                })
                                            }, id);
                                        })
                                    })
                                })
                            ]
                        })
                    ]
                })
            }),
            getModal && /*#__PURE__*/ jsx_runtime_.jsx(modal_ModalMain, {
                modalId: modalId,
                setGetModal: setGetModal
            }),
            " "
        ]
    });
};
/* harmony default export */ const portfolio_Portfolio = (Portfolio);


/***/ }),

/***/ 1281:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ switch_SwitchDark)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
;// CONCATENATED MODULE: ./public/assets/img/sun.png
/* harmony default export */ const sun = ({"src":"/_next/static/media/sun.e8a19ea6.png","height":24,"width":24,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAQAAABuBnYAAAAASklEQVR42l2NwQ2AMAzEHB4VI5SVskI3yMrtLmCJRxFyHvFJl8BBACkQmlM0LmmUBpwMlgw3IOnKLcstv8HEYFfmW9lHu1oE/7cPkP0RT+u5jqgAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./utils/theme.js
function handleSwitchValue(value) {
    if (value) {
        localStorage.setItem("theme-color", "dark");
        document.querySelector("body").classList.add("dark");
        document.querySelector("body").classList.remove("light");
    } else {
        localStorage.setItem("theme-color", "light");
        document.querySelector("body").classList.add("light");
        document.querySelector("body").classList.remove("dark");
    }
}
/* harmony default export */ const theme = (handleSwitchValue);

;// CONCATENATED MODULE: ./src/components/switch/SwitchDark.jsx





const SwitchDark = ()=>{
    const [isDark, setIsDark] = (0,external_react_.useState)(false);
    const handleLabelClick = ()=>{
        if (isDark) {
            theme(true);
            setIsDark(false);
        } else {
            theme(false);
            setIsDark(true);
        }
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("label", {
        className: `theme-switcher-label d-flex  ${isDark ? "active" : ""}`,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("input", {
                type: "checkbox",
                onClick: handleLabelClick,
                className: "theme-switcher"
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "switch-handle",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        className: "light-text",
                        children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                            src: sun,
                            alt: "swicher",
                            className: "filter_1",
                            priority: true
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        className: "dark-text",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                            className: "fa fa-moon-o",
                            "aria-hidden": "true"
                        })
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const switch_SwitchDark = (SwitchDark);


/***/ }),

/***/ 5532:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3590);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_toastify__WEBPACK_IMPORTED_MODULE_2__]);
react_toastify__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];



const Wrapper = ({ children  })=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            children,
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_toastify__WEBPACK_IMPORTED_MODULE_2__.ToastContainer, {})
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Wrapper);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8819:
/***/ (() => {



/***/ }),

/***/ 782:
/***/ (() => {



/***/ }),

/***/ 8278:
/***/ (() => {



/***/ })

};
;