import React from "react";



const AboutParaArabic = () => {
  const mystyle = {
    fontSize: '25px'
  };
  return (
    <>
     <div>
    <p style= {mystyle}>
    زين العراق هي احدى الشركات الرائدة في مجال الاستثمارات العقارية و التطوير العمراني باستخدام احدث وسائل التكنلوجيا العمرانية الحديثة
نبحث عن التميز و الأبداع في اعمالنا من خلال طرح اسلوب حياة جديد و عصري بواجهات و تصاميم فريده تواكب تطورات العصر الجديد

     </p>
     
      <h3 className="text-uppercase pb-4 pb-sm-5 mb-3 mb-sm-0 text-start text-sm-center custom-title ft-wt-600">
      نهج عملنا
            </h3>
      <p style= {mystyle}>بخطى مدروسة و كوادرنا الفنية في مجالات التصميم و التنفيذ نسعى لإضافة الحداثة الى اعمالنا لتساهم اعمالنا في احداث تأثير ايجابي في المجتمع

    </p>

     </div>
    </>
  );
};

export default AboutParaArabic;
