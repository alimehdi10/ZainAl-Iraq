"use strict";
exports.id = 572;
exports.ids = [572];
exports.modules = {

/***/ 8572:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ pages_preview)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
;// CONCATENATED MODULE: ./public/assets/img/intro/dark.jpg
/* harmony default export */ const dark = ({"src":"/_next/static/media/dark.c70a123f.jpg","height":1080,"width":1920,"blurDataURL":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAUACAMBIgACEQEDEQH/xAAnAAEBAAAAAAAAAAAAAAAAAAAABgEBAAAAAAAAAAAAAAAAAAAAA//aAAwDAQACEAMQAAAAgQKf/8QAHBABAAEEAwAAAAAAAAAAAAAAAQMAAgQRBRJx/9oACAEBAAE/AOWyhzJxgjUsitLkNnVV17X/xAAYEQADAQEAAAAAAAAAAAAAAAABAgMAMf/aAAgBAgEBPwCJLSmx6VG//8QAGBEAAgMAAAAAAAAAAAAAAAAAAQIAIVH/2gAIAQMBAT8AenYDZ//Z","blurWidth":8,"blurHeight":5});
;// CONCATENATED MODULE: ./public/assets/img/intro/rtl.jpg
/* harmony default export */ const rtl = ({"src":"/_next/static/media/rtl.5f54f130.jpg","height":1080,"width":1920,"blurDataURL":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAUACAMBIgACEQEDEQH/xAAoAAEBAAAAAAAAAAAAAAAAAAAABwEBAQAAAAAAAAAAAAAAAAAAAgP/2gAMAwEAAhADEAAAAJ6JP//EABwQAAIABwAAAAAAAAAAAAAAAAIDAAEEBREV4f/aAAgBAQABPwC71I7BkzSJYWIdj//EABkRAAMAAwAAAAAAAAAAAAAAAAECAwAhIv/aAAgBAgEBPwCPcZs2yVGf/8QAGBEAAgMAAAAAAAAAAAAAAAAAAQIAIVH/2gAIAQMBAT8AenYDTP/Z","blurWidth":8,"blurHeight":5});
// EXTERNAL MODULE: ./src/components/Seo.jsx
var Seo = __webpack_require__(1690);
;// CONCATENATED MODULE: ./src/pages/preview.jsx






const preview = ()=>{
    const previewDemo = [
        {
            img: dark,
            title: "English",
            routerPath: "/home-dark",
            delayAnimation: "50"
        },
        {
            img: rtl,
            title: "عربي",
            routerPath: "/home-rtl",
            delayAnimation: "150"
        }
    ];
    const mystyle = {
        fontSize: "30px"
    };
    const mystyle2 = {
        fontSize: "30px",
        color: "yellow"
    };
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ jsx_runtime_.jsx("section", {
            className: "demo dark",
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "container",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                        style: mystyle,
                        children: "Zain Al Iraq"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "row",
                        children: previewDemo.map((val, i)=>/*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "col-xs-12 col-sm-6 col-md-6",
                                "data-aos": "fade-down",
                                "data-aos-duration": "2000",
                                "data-aos-delay": val.delayAnimation,
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "content text-center",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "bg_container",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                href: val.routerPath,
                                                target: "_blank",
                                                rel: "noreferrer",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                    src: val.img,
                                                    alt: "demo",
                                                    className: "img-responsive screenshot",
                                                    style: {
                                                        width: "100%",
                                                        height: "80%"
                                                    }
                                                })
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                            className: "demo-title",
                                            children: val.title
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "anchor"
                                        })
                                    ]
                                })
                            }, i))
                    })
                ]
            })
        })
    });
};
/* harmony default export */ const pages_preview = (preview);


/***/ })

};
;